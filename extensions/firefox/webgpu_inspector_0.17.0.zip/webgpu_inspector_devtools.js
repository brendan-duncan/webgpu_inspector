chrome.devtools.panels.create(
  "WebGPU Inspector",
  "/res/webgpu_inspector_on-38.png",
  "/webgpu_inspector_panel.html"
);
